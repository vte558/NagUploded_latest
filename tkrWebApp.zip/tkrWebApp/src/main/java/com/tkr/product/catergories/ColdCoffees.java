package com.tkr.product.catergories;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.tkr.util.Constants;

@Component
public class ColdCoffees {

	Map<String, Integer> mp = new HashMap<String, Integer>();

	int VANILLA, CREAM, MILK, COFFEESYRUP, CHOCOSYRUP, GLASS350ml;
	@Autowired
	private ThickShakes thickShakes;

	public ColdCoffees() {
		mp.put("VANILLA", 150);
		mp.put("COFFEESYRUP", 20);
		mp.put("CHOCOSYRUP", 20);
		mp.put("MILK", 100);
		mp.put("GLASS350ml", 1);

	}

	public boolean classicColdCoffee() throws SQLException {
		mp.put(Constants.MILK, 120);
		thickShakes.commonMethod(mp);
		return true;

	}

	public boolean oreoBlackCoffee() throws SQLException {

		mp.put(Constants.OREOCOOKIE, 1);
		thickShakes.commonMethod(mp);
		return true;

	}

	public boolean chocoColdCoffee() throws SQLException {

		mp.put(Constants.CHOCOCHIPS, 10);
		thickShakes.commonMethod(mp);
		return true;

	}

}
