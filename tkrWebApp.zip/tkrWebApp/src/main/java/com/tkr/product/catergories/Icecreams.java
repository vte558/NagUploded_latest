package com.tkr.product.catergories;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.tkr.util.Constants;

@Component
public class Icecreams {

	private ThickShakes thickShakes = new ThickShakes();
	Map<String, Integer> mp = new HashMap<String, Integer>();

	public boolean doubleChocBrownieWithIcecream() throws SQLException {

		mp.put(Constants.VANILLA, 90);
		mp.put(Constants.BROWNIE, 90);
		mp.put(Constants.CHOCOSYRUP, 5);
		mp.put(Constants.KAJU, 5);
		mp.put(Constants.BROWNIECUP, 1);
		thickShakes.commonMethod(mp);
		return true;

	}

	public boolean vanillaICECREAMR(String saleType) throws SQLException {

		mp.put(Constants.VANILLA, 90);

		if (saleType.equals("walkin")) {
			mp.put(Constants.ICECREAMCUP100ml, 1);
		} else if (saleType.equals("online")) {
			mp.put(Constants.ICECREAMCUP200ml, 1);
		}

		thickShakes.commonMethod(mp);
		return true;
	}

	public boolean vanillaICECREAML() throws SQLException {

		mp.put(Constants.VANILLA, 140);
		mp.put(Constants.ICECREAMCUP200ml, 1);
		thickShakes.commonMethod(mp);
		return true;

	}

	public boolean chocolateICECREAMR(String saleType) throws SQLException {

		mp.put(Constants.CHOCOLATEICECREAM, 90);
		if (saleType.equals("walkin")) {
			mp.put(Constants.ICECREAMCUP100ml, 1);
		} else if (saleType.equals("online")) {
			mp.put(Constants.ICECREAMCUP200ml, 1);
		}

		thickShakes.commonMethod(mp);
		return true;
	}

	public boolean chocolateICECREAML() throws SQLException {

		mp.put(Constants.CHOCOLATEICECREAM, 140);
		mp.put(Constants.ICECREAMCUP200ml, 1);
		thickShakes.commonMethod(mp);
		return true;

	}

	public boolean butterScotchICECREAMR(String saleType) throws SQLException {

		mp.put(Constants.BUTTERSCOTCHICECREAM, 90);
		if (saleType.equals("walkin")) {
			mp.put(Constants.ICECREAMCUP100ml, 1);
		} else if (saleType.equals("online")) {
			mp.put(Constants.ICECREAMCUP200ml, 1);
		}

		thickShakes.commonMethod(mp);
		return true;
	}

	public boolean butterScotchICECREAML() throws SQLException {

		mp.put(Constants.BUTTERSCOTCHICECREAM, 140);
		mp.put(Constants.ICECREAMCUP200ml, 1);

		thickShakes.commonMethod(mp);
		return true;
	}

	public boolean jamicanICECREAMR(String saleType) throws SQLException {

		mp.put(Constants.JAMICANICECREAM, 90);
		if (saleType.equals("walkin")) {
			mp.put(Constants.ICECREAMCUP100ml, 1);
		} else if (saleType.equals("online")) {
			mp.put(Constants.ICECREAMCUP200ml, 1);
		}

		thickShakes.commonMethod(mp);
		return true;
	}

	public boolean jamicanICECREAML() throws SQLException {
		mp.put(Constants.JAMICANICECREAM, 140);
		mp.put(Constants.ICECREAMCUP200ml, 1);
		thickShakes.commonMethod(mp);
		return true;
	}

	public boolean belgiumDarkChocICECREAMR(String saleType) throws SQLException {

		mp.put(Constants.BELGIUMDARKCHOCICECREAM, 90);
		if (saleType.equals("walkin")) {
			mp.put(Constants.ICECREAMCUP100ml, 1);
		} else if (saleType.equals("online")) {
			mp.put(Constants.ICECREAMCUP200ml, 1);
		}

		thickShakes.commonMethod(mp);
		return true;
	}

	public boolean belgiumDarkChocICECREAML() throws SQLException {

		mp.put(Constants.BELGIUMDARKCHOCICECREAM, 140);
		mp.put(Constants.ICECREAMCUP200ml, 1);
		thickShakes.commonMethod(mp);
		return true;
	}

	public boolean jaggeryICECREAMR(String saleType) throws SQLException {

		mp.put(Constants.JAGGERYICECREAM, 90);

		if (saleType.equals("walkin")) {
			mp.put(Constants.ICECREAMCUP100ml, 1);
		} else if (saleType.equals("online")) {
			mp.put(Constants.ICECREAMCUP200ml, 1);
		}

		thickShakes.commonMethod(mp);
		return true;
	}

	public boolean jaggeryICECREAML() throws SQLException {

		mp.put(Constants.JAGGERYICECREAM, 140);
		mp.put(Constants.ICECREAMCUP200ml, 1);
		thickShakes.commonMethod(mp);
		return true;
	}

	public boolean NuttyCaramelICECREAMR(String saleType) throws SQLException {

		mp.put(Constants.NUTTYCARAMELICECREAM, 90);
		if (saleType.equals("walkin")) {
			mp.put(Constants.ICECREAMCUP100ml, 1);
		} else if (saleType.equals("online")) {
			mp.put(Constants.ICECREAMCUP200ml, 1);
		}

		thickShakes.commonMethod(mp);
		return true;
	}

	public boolean NuttyCaramelICECREAML() throws SQLException {

		mp.put(Constants.NUTTYCARAMELICECREAM, 140);
		mp.put(Constants.ICECREAMCUP200ml, 1);
		thickShakes.commonMethod(mp);
		return true;
	}

	public boolean fruitJellyICECREAMR(String saleType) throws SQLException {

		mp.put(Constants.FRUITJELLYICECREAM, 90);

		if (saleType.equals("walkin")) {
			mp.put(Constants.ICECREAMCUP100ml, 1);
		} else if (saleType.equals("online")) {
			mp.put(Constants.ICECREAMCUP200ml, 1);
		}

		thickShakes.commonMethod(mp);
		return true;
	}

	public boolean fruitJellyICECREAML() throws SQLException {

		mp.put(Constants.FRUITJELLYICECREAM, 140);
		mp.put(Constants.ICECREAMCUP200ml, 1);
		thickShakes.commonMethod(mp);
		return true;
	}

	public boolean honeyAlmondICECREAMR(String saleType) throws SQLException {

		mp.put(Constants.HONEYALMONDICECREAM, 90);

		if (saleType.equals("walkin")) {
			mp.put(Constants.ICECREAMCUP100ml, 1);
		} else if (saleType.equals("online")) {
			mp.put(Constants.ICECREAMCUP200ml, 1);
		}

		thickShakes.commonMethod(mp);
		return true;
	}

	public boolean honeyAlmondICECREAML() throws SQLException {

		mp.put(Constants.HONEYALMONDICECREAM, 140);
		mp.put(Constants.ICECREAMCUP200ml, 1);
		thickShakes.commonMethod(mp);
		return true;
	}

	public boolean shahiGulabICECREAMR(String saleType) throws SQLException {

		mp.put(Constants.SHAHIGULABICECREAM, 90);
		if (saleType.equals("walkin")) {
			mp.put(Constants.ICECREAMCUP100ml, 1);
		} else if (saleType.equals("online")) {
			mp.put(Constants.ICECREAMCUP200ml, 1);
		}

		thickShakes.commonMethod(mp);
		return true;
	}

	public boolean shahiGulabICECREAML() throws SQLException {

		mp.put(Constants.SHAHIGULABICECREAM, 140);
		mp.put(Constants.ICECREAMCUP200ml, 1);
		thickShakes.commonMethod(mp);
		return true;
	}

	public boolean panMasalaICECREAMR(String saleType) throws SQLException {

		mp.put(Constants.PANMASALAICECREAM, 90);

		if (saleType.equals("walkin")) {
			mp.put(Constants.ICECREAMCUP100ml, 1);
		} else if (saleType.equals("online")) {
			mp.put(Constants.ICECREAMCUP200ml, 1);
		}

		thickShakes.commonMethod(mp);
		return true;
	}

	public boolean panMasalaICECREAML() throws SQLException {

		mp.put(Constants.PANMASALAICECREAM, 140);
		mp.put(Constants.ICECREAMCUP200ml, 1);
		thickShakes.commonMethod(mp);
		return true;
	}

	public boolean birthdaycakeICECREAMR(String saleType) throws SQLException {

		mp.put(Constants.BIRTHDAYCAKEICECREAM, 90);

		if (saleType.equals("walkin")) {
			mp.put(Constants.ICECREAMCUP100ml, 1);
		} else if (saleType.equals("online")) {
			mp.put(Constants.ICECREAMCUP200ml, 1);
		}

		thickShakes.commonMethod(mp);
		return true;
	}

	public boolean birthdaycakeICECREAML() throws SQLException {

		mp.put(Constants.BIRTHDAYCAKEICECREAM, 140);
		mp.put(Constants.ICECREAMCUP200ml, 1);
		thickShakes.commonMethod(mp);
		return true;
	}

	public boolean anjeerBadamICECREAMR(String saleType) throws SQLException {

		mp.put(Constants.ANJEERBADAMICECREAM, 90);
		if (saleType.equals("walkin")) {
			mp.put(Constants.ICECREAMCUP100ml, 1);
		} else if (saleType.equals("online")) {
			mp.put(Constants.ICECREAMCUP200ml, 1);
		}

		thickShakes.commonMethod(mp);
		return true;
	}

	public boolean anjeerBadamICECREAML() throws SQLException {

		mp.put(Constants.ANJEERBADAMICECREAM, 140);
		mp.put(Constants.ICECREAMCUP200ml, 1);
		thickShakes.commonMethod(mp);
		return true;
	}

	public boolean dryFruitsICECREAMR(String saleType) throws SQLException {

		mp.put(Constants.DRYFRUITSICECREAM, 90);
		if (saleType.equals("walkin")) {
			mp.put(Constants.ICECREAMCUP100ml, 1);
		} else if (saleType.equals("online")) {
			mp.put(Constants.ICECREAMCUP200ml, 1);
		}

		thickShakes.commonMethod(mp);
		return true;
	}

	public boolean dryFruitsICECREAML() throws SQLException {

		mp.put(Constants.DRYFRUITSICECREAM, 140);
		mp.put(Constants.ICECREAMCUP200ml, 1);
		thickShakes.commonMethod(mp);
		return true;
	}

}
