package com.tkr.product.catergories;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.tkr.util.Constants;

@Component
public class Snacks {
	@Autowired
	private ThickShakes thickShakes;
	Map<String, Integer> mp = new HashMap<String, Integer>();

	static Snacks snack = new Snacks();
	static Crushers crusher = new Crushers();

	public boolean frenchFries() throws SQLException {
		mp.put(Constants.FRENCHFRIES, 150);
		mp.put(Constants.SILVERBOX, 1);
		thickShakes.commonMethod(mp);
		return true;

	}

	public boolean chickenPopCorn() throws SQLException {
		mp.put(Constants.CHICKENPOPCORN, 100);
		mp.put(Constants.SILVERBOX, 1);
		thickShakes.commonMethod(mp);
		return true;

	}

	public boolean chickenNuggets() throws SQLException {
		mp.put(Constants.CHICKENNUGGETS, 120);
		mp.put(Constants.SILVERBOX, 1);
		thickShakes.commonMethod(mp);
		return true;

	}

	public boolean chickenPlatter() throws SQLException {
		mp.put(Constants.CHICKENNUGGETS, 60);
		mp.put(Constants.CHICKENPOPCORN, 60);
		mp.put(Constants.SILVERBOX, 1);
		thickShakes.commonMethod(mp);
		return true;

	}

	public boolean frenchCombo() throws SQLException {

		snack.frenchFries();
		crusher.virginMojito();

		return true;

	}

	public boolean nuggetsCombo() throws SQLException {
		snack.chickenNuggets();
		crusher.virginMojito();
		return true;

	}

	public boolean popcornCombo() throws SQLException {
		snack.chickenPopCorn();
		crusher.virginMojito();
		return true;

	}

}
