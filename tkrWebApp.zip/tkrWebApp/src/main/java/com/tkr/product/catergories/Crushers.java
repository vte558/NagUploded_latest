package com.tkr.product.catergories;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.tkr.util.Constants;

@Component
public class Crushers {
	@Autowired
	private ThickShakes thickShakes;

	Map<String, Integer> mp = new HashMap<String, Integer>();

	public boolean virginMojito() throws SQLException {
		mp.put(Constants.LEMON, 1);
		mp.put(Constants.MINT, 5);
		mp.put(Constants.MOJITOSYRUP, 15);
		mp.put(Constants.GLASS350ml, 1);
		mp.put(Constants.SPRITE, 250);
		thickShakes.commonMethod(mp);
		return true;

	}

	public boolean pinaColada() throws SQLException {

		mp.put(Constants.VANILLA, 50);
		mp.put(Constants.CREAM, 40);
		mp.put(Constants.PINACOLADASYRUP, 50);
		mp.put(Constants.TROPICANA, 150);
		mp.put(Constants.GLASS350ml, 1);

		thickShakes.commonMethod(mp);

		return true;

	}

	public boolean rjyRoseMilk() throws SQLException {

		mp.put(Constants.VANILLA, 50);
		mp.put(Constants.ROSESYRUP, 50);
		mp.put(Constants.KOVA, 50);
		mp.put(Constants.MILK, 150);
		mp.put(Constants.GLASS350ml, 1);
		thickShakes.commonMethod(mp);
		return true;

	}

}
