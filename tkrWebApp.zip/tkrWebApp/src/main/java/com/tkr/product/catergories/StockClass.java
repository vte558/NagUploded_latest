package com.tkr.product.catergories;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.tkr.util.GetConnection;

@Component
public class StockClass {
	@Autowired
	private GetConnection getConnectionObj;

	String ProductName;
	Statement st = null;
	ResultSet rs1 = null;

	public String getSales() throws SQLException {
		String str1 = "select * form tkr_sales";
		ResultSet rs1 = null;
		Connection con = getConnectionObj.getConnection();
		st = con.createStatement();
		rs1 = st.executeQuery(str1);

		while (((ResultSet) rs1).next()) {
			ProductName = ((ResultSet) rs1).getString("ProductName");

			System.out.println("ProductNameProductName---->" + ProductName);

		}
		return ProductName;

	}
}
