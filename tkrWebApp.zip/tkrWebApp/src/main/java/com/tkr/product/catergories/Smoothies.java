package com.tkr.product.catergories;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.tkr.util.Constants;

@Component
public class Smoothies {
	@Autowired
	private ThickShakes thickShakes;
	Map<String, Integer> mp = new HashMap<String, Integer>();
	int VANILLA, CREAM, MILK, GLASS350ml;

	public Smoothies() {
		mp.put("VANILLA", 160);
		mp.put("CREAM", 40);
		mp.put("MILK", 60);
		mp.put("GLASS350ml", 1);

	}

	public boolean bananaThickSmoothie() throws SQLException {

		mp.put(Constants.BANANA, 100);
		thickShakes.commonMethod(mp);
		return true;

	}

	public boolean sapotaThickSmoothie() throws SQLException {

		mp.put(Constants.SAPOTA, 100);
		thickShakes.commonMethod(mp);
		return true;
	}

	public boolean appleThickSmoothie() throws SQLException {
		mp.put(Constants.APPLE, 100);
		thickShakes.commonMethod(mp);
		return true;

	}

	public boolean muskmelonThickSmoothie() throws SQLException {
		mp.put(Constants.MUSKMELON, 100);
		thickShakes.commonMethod(mp);
		return true;
	}

	public boolean watermelonThickSmoothie() throws SQLException {
		mp.put(Constants.WATERMELON, 100);
		thickShakes.commonMethod(mp);
		return true;
	}

	public boolean seethapalThickSmoothie() throws SQLException {
		mp.put(Constants.SEETHAPAL, 100);
		thickShakes.commonMethod(mp);
		return true;
	}
}
