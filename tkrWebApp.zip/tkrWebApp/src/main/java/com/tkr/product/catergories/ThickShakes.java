package com.tkr.product.catergories;

import java.sql.Connection;
import java.sql.Date;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.tkr.util.Constants;
import com.tkr.util.GetConnection;

@Component
public class ThickShakes {

	GetConnection getConnectionObj = new GetConnection();

	Map<String, Integer> mp = new HashMap<String, Integer>();
	int VANILLA, CREAM, MILK, GLASS350ml;

	public ThickShakes() {
		mp.put("VANILLA", 180);
		mp.put("CREAM", 40);
		mp.put("MILK", 60);
		mp.put("GLASS350ml", 1);

	}

	public boolean commonMethod(Map<String, Integer> mp) throws SQLException {
		try {
			Connection con = getConnectionObj.getConnection();
			Statement st = null;
			for (Entry<String, Integer> entry : mp.entrySet()) {
				String str = "update tkr_products set quantity=quantity-" + entry.getValue() + " where ProductName='"
						+ entry.getKey() + "'";
				System.out.println("str------->>>>>>> in Thickshakes class commonMethod " + str);
				st = con.createStatement();
				st.execute(str);

			}

		} catch (Exception e) {

			e.printStackTrace();
		}

		return true;
	}

	public boolean crunchyMunchThickShake() throws SQLException {

		mp.put(Constants.MUNCHCHOC, 1);
		mp.put(Constants.CHOCOCHIPS, 5);
		commonMethod(mp);
		return true;

	}

	public boolean fiveStarThickShake() throws SQLException {

		mp.put(Constants.FIVESTARCHOC, 1);
		mp.put(Constants.CHOCOCHIPS, 5);
		commonMethod(mp);
		return true;

	}

	public boolean snickersThickShake() throws SQLException {

		mp.put(Constants.SNICKERCHOC, 1);
		mp.put(Constants.CHOCOCHIPS, 5);
		commonMethod(mp);

		return true;

	}

	public boolean chocoKitkatThickShake() throws SQLException {

		mp.put(Constants.CHOCOPIE, 1);
		mp.put(Constants.KITKATCHOC, 1);
		mp.put(Constants.CHOCOCHIPS, 5);
		commonMethod(mp);
		return true;

	}

	public boolean dairyMilkThickShake() throws SQLException {

		mp.put(Constants.DAIRYMILKCHOC, 1);
		mp.put(Constants.CHOCOCHIPS, 5);
		commonMethod(mp);

		return true;

	}

	public boolean belgiumDarkChocThickShake() throws SQLException {

		mp.put(Constants.VANILLA, 200);
		mp.put(Constants.COCOPOWDER, 10);
		mp.put(Constants.CHOCOSYRUP, 20);
		mp.put(Constants.CHOCOCHIPS, 10);
		commonMethod(mp);
		return true;

	}

	public boolean bourbonThickShake() throws SQLException {

		mp.put(Constants.BOURBONCOOKIE, 50);
		mp.put(Constants.CHOCOCHIPS, 5);
		commonMethod(mp);

		return true;

	}

	public boolean hideNSeekThickShake() throws SQLException {

		mp.put(Constants.HIDENSEEKCOOKIE, 50);
		mp.put(Constants.CHOCOCHIPS, 5);
		commonMethod(mp);

		return true;

	}

	public boolean darkFantasyThickShake() throws SQLException {

		mp.put(Constants.DARKFANTASYCOOKIE, 4);
		mp.put(Constants.CHOCOCHIPS, 5);
		commonMethod(mp);

		return true;

	}

	public boolean chocoAlmondThickShake() throws SQLException {

		mp.put(Constants.BADAM, 10);
		mp.put(Constants.HAPPYHAPPYCOOKIE, 1);
		mp.put(Constants.CHOCOCHIPS, 5);
		commonMethod(mp);

		return true;

	}

	public boolean chocoChipsThickShake() throws SQLException {

		mp.put(Constants.CHOCOCHIPS, 10);
		mp.put(Constants.HAPPYHAPPYCOOKIE, 1);
		commonMethod(mp);

		return true;
	}

	public boolean realOreoThickShake() throws SQLException {

		mp.put(Constants.OREOCOOKIE, 1);
		mp.put(Constants.CHOCOCHIPS, 5);
		commonMethod(mp);

		return true;
	}

	public boolean oreoCaramelThickShake() throws SQLException {

		mp.put(Constants.OREOCOOKIE, 1);
		mp.put(Constants.CARAMELSYRUP, 20);
		mp.put(Constants.CHOCOCHIPS, 5);
		commonMethod(mp);
		return true;
	}

	public boolean bananaOreoTickShake() throws SQLException {

		mp.put(Constants.OREOCOOKIE, 1);
		mp.put(Constants.BANANA, 20);
		mp.put(Constants.CHOCOCHIPS, 5);
		commonMethod(mp);
		return true;
	}

	public boolean oreoBrownieTickShake() throws SQLException {

		mp.put(Constants.OREOCOOKIE, 1);
		mp.put(Constants.BROWNIE, 30);
		mp.put(Constants.CHOCOCHIPS, 5);
		commonMethod(mp);
		return true;
	}

	public boolean classicDoubleChocolateBrownieThickShake() throws SQLException {

		mp.put(Constants.BROWNIE, 50);
		mp.put(Constants.CHOCOCHIPS, 5);
		commonMethod(mp);

		return true;
	}

	public boolean tripleChocoBrownieThickShake() throws SQLException {

		mp.put(Constants.BROWNIE, 50);
		mp.put(Constants.CHOCOCHIPS, 10);
		commonMethod(mp);

		return true;
	}

	public boolean iconicNutellaThickShake() throws SQLException {

		mp.put(Constants.NUTELLA, 40);
		mp.put(Constants.CHOCOCHIPS, 5);
		commonMethod(mp);

		return true;
	}

	public boolean gulabJamunThickShake() throws SQLException {

		mp.put(Constants.GULABJAM, 2);
		commonMethod(mp);

		return true;
	}

	public boolean sweetPanThickShake() throws SQLException {
		mp.put(Constants.VANILLA, 200);
		mp.put(Constants.PANCREAM, 15);
		mp.put(Constants.PANDATES, 15);
		commonMethod(mp);
		return true;
	}

	public boolean rosePetalThickShake() throws SQLException {

		mp.put(Constants.ROSESYRUP, 30);
		commonMethod(mp);

		return true;
	}

	public boolean nutsOverLoadedThickShake() throws SQLException {
		mp.put(Constants.VANILLA, 200);
		mp.put(Constants.PISTA, 7);
		mp.put(Constants.BADAM, 14);
		mp.put(Constants.KAJU, 14);

		commonMethod(mp);

		return true;
	}

	public boolean healthyDatesThickShake() throws SQLException {

		mp.put(Constants.DATES, 40);
		mp.put(Constants.KAJU, 10);

		commonMethod(mp);

		return true;

	}

	public boolean deliciousDryFruitsThickShake() throws SQLException {

		mp.put(Constants.ANJEER, 20);
		mp.put(Constants.DATES, 20);
		mp.put(Constants.KAJU, 10);

		commonMethod(mp);

		return true;

	}

	public boolean nutellaBrownieThickShake() throws SQLException {

		mp.put(Constants.NUTELLA, 20);
		mp.put(Constants.BROWNIE, 30);
		mp.put(Constants.CHOCOCHIPS, 5);
		commonMethod(mp);
		return true;
	}

}
