package com.tkr.product.catergories;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.tkr.util.Constants;

@Component
public class Lassis {
	@Autowired
	private ThickShakes thickShakes;
	Map<String, Integer> mp = new HashMap<String, Integer>();

	int VANILLA, CREAM, MILK, COFFEESYRUP, CHOCOSYRUP, GLASS250ml;

	public Lassis() {
		mp.put("VANILLA", 60);
		mp.put("CURD", 150);
		mp.put("GLASS250ML", 1);
		mp.put("SUGAR", 10);

	}

	public boolean classicLassi() throws SQLException {

		thickShakes.commonMethod(mp);
		return true;

	}

	public boolean bananaLassi() throws SQLException {
		mp.put(Constants.BANANAFLAVOUR, 20);
		thickShakes.commonMethod(mp);
		return true;

	}

	public boolean guavaLassi() throws SQLException {
		mp.put(Constants.GUAVAFLAVOUR, 20);
		thickShakes.commonMethod(mp);
		return true;

	}

	public boolean mangoLassi() throws SQLException {
		mp.put(Constants.MANGOFLAVOUR, 20);
		thickShakes.commonMethod(mp);
		return true;

	}

	public boolean litchiLassi() throws SQLException {
		mp.put(Constants.LITCHIFLAVOUR, 20);
		thickShakes.commonMethod(mp);
		return true;

	}

	public boolean greenAppleLassi() throws SQLException {
		mp.put(Constants.GREENAPPLEFLAVOUR, 20);
		thickShakes.commonMethod(mp);
		return true;

	}

	public boolean mulberryLassi() throws SQLException {
		mp.put(Constants.MULBERRYFLAVOUR, 20);
		thickShakes.commonMethod(mp);
		return true;

	}

	public boolean pineAppleLassi() throws SQLException {
		mp.put(Constants.PINEAPPLEFLAVOUR, 20);
		thickShakes.commonMethod(mp);
		return true;

	}

	public boolean orangeLassi() throws SQLException {
		mp.put(Constants.ORANGEFLAVOUR, 20);
		thickShakes.commonMethod(mp);
		return true;

	}

	public boolean specialLassi() throws SQLException {
		mp.put(Constants.BADAM, 8);
		mp.put(Constants.KAJU, 8);
		mp.put(Constants.PISTA, 4);
		thickShakes.commonMethod(mp);
		return true;

	}

}
