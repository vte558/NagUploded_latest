package com.tkr;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.tkr.*")
public class TkrWebAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(TkrWebAppApplication.class, args);
	}

}
