package com.tkr.util;

import java.sql.Connection;
import java.sql.DriverManager;

import org.springframework.stereotype.Component;
@Component
public class GetConnection {

	public Connection getConnection() {
		Connection conn =null;
		try{  
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			String URL ="jdbc:sqlserver://tkrproddb.cjkunhon3itm.ap-south-1.rds.amazonaws.com:1433;databaseName=tkrdb;user=tkradmin;password=ackpthpt;";  
			String user = "tkradmin";
	            String pass = "ackpthpt";
	             conn = DriverManager.getConnection(URL, user, pass);
	           System.out.println("Con-->"+conn);
		
	           
			}catch(Exception e){ 
				System.out.println(e);
			}  
			
		return conn;
	}
	
}
