package com.tkr.util;

import org.springframework.stereotype.Component;

@Component
public class Constants {
	
	
//total "73" constants as of SEP
	
	public static final String VANILLA = "VANILLA";
	public static final String CREAM = "CREAM";
	public static final String MILK = "MILK";
	public static final String GLASS350ml = "GLASS350ml";
	public static final String GLASS250ml = "GLAS250ml";
	public static final String ICECREAMCUP100ml="ICECREAMCUP100ml";
	public static final String ICECREAMCUP200ml="ICECREAMCUP200ml";
	public static final String  SUGAR="SUGAR";
	public static final String  CURD="CURD";
	public static final String  BROWNIECUP="BROWNIECUP";
	
//choclates
	public static final String MUNCHCHOC = "MUNCHCHOC";
	public static final String FIVESTARCHOC = "FIVESTARCHOC";
	public static final String SNICKERCHOC = "SNICKERCHOC";
	public static final String CHOCOPIE = "CHOCOPIE";
	public static final String KITKATCHOC = "KITKATCHOC";
	public static final String DAIRYMILKCHOC = "DAIRYMILKCHOC";
	public static final String COCOPOWDER = "COCOPOWDER";
//cookies
	public static final String BOURBONCOOKIE = "BOURBONCOOKIE";
	public static final String HIDENSEEKCOOKIE = "HIDENSEEKCOOKIE";
	public static final String DARKFANTASYCOOKIE = "DARKFANTASYCOOKIE";
	public static final String HAPPYHAPPYCOOKIE = "HAPPYHAPPYCOOKIE";
	public static final String OREOCOOKIE = "OREOCOOKIE";
	public static final String CHOCOCHIPS = "CHOCOCHIPS";
//fruits
	public static final String BANANA = "BANANA";
	public static final String SAPOTA = "SAPOTA";
	public static final String APPLE = "APPLE";
	public static final String WATERMELON = "WATERMELON";
	public static final String MUSKMELON = "MUSKMELON";
	public static final String SEETHAPAL="SEETHAPAL";

	public static final String BROWNIE = "BROWNIE";
	public static final String NUTELLA = "NUTELLA";
	public static final String GULABJAM = "GULABJAM";
	public static final String PANCREAM = "PANCREAM";
	public static final String PANDATES = "PANDATES";
//nuts&Dryfruits
	
	public static final String BADAM = "BADAM";
	public static final String PISTA = "PISTA";
	public static final String DATES = "DATES";
	public static final String ANJEER = "ANJEER";
	public static final String KAJU = "KAJU";
//syrups&sauce
	public static final String CHOCOSYRUP = "CHOCOSYRUP";
	public static final String CARAMELSYRUP = "CARAMELSYRUP";
	public static final String ROSESYRUP = "ROSESYRUP";
	public static final String COFFEESYRUP = "COFFEESYRUP";
	public static final String PINACOLADASYRUP = "PINACOLADASYRUP";
	public static final String MOJITOSYRUP = "MOJITOSYRUP";

	public static final String HONEY = "HONEY";
	public static final String TROPICANA = "TROPICANA";
	public static final String KOVA = "KOVA";
	public static final String LEMON = "LEMON";
	public static final String MINT = "MINT";
	public static final String SPRITE = "SPRITE";
//ICECREAMS
	public static final String CHOCOLATEICECREAM = "CHOCOLATEICECREAM";
	public static final String BUTTERSCOTCHICECREAM = "BUTTERSCOTCHICECREAM";
	public static final String JAMICANICECREAM = "JAMICANICECREAM";
	public static final String BELGIUMDARKCHOCICECREAM = "BELGIUMDARKCHOCICECREAM";
	public static final String JAGGERYICECREAM = "JAGGERYICECREAM";
	public static final String NUTTYCARAMELICECREAM = "NUTTYCARAMELICECREAM";
	public static final String FRUITJELLYICECREAM = "FRUITJELLYICECREAM";
	public static final String HONEYALMONDICECREAM = "HONEYALMONDICECREAM";
	public static final String SHAHIGULABICECREAM = "SHAHIGULABICECREAM";
	public static final String PANMASALAICECREAM = "PANMASALAICECREAM";
	public static final String BIRTHDAYCAKEICECREAM = "BIRTHDAYCAKEICECREAM";
	public static final String ANJEERBADAMICECREAM = "ANJEERBADAMICECREAM";
	public static final String DRYFRUITSICECREAM = "DRYFRUITSICECREAM";
//Flavours
	public static final String BANANAFLAVOUR = "BANANAFLAVOUR";
	public static final String GUAVAFLAVOUR = "GUAVAFLAVOUR";
	public static final String MANGOFLAVOUR = "MANGOFLAVOUR";
	public static final String LITCHIFLAVOUR = "LITCHIFLAVOUR";
	public static final String GREENAPPLEFLAVOUR = "GREENAPPLEFLAVOUR";
	public static final String MULBERRYFLAVOUR = "MULBERRYFLAVOUR";
	public static final String PINEAPPLEFLAVOUR = "PINEAPPLEFLAVOUR";
	public static final String ORANGEFLAVOUR = "ORANGEFLAVOUR";
	public static final String NUTSPOWDER = "NUTSPOWDER";
//snacks	
	public static final String FRENCHFRIES = "FRENCHFRIES";
	public static final String CHICKENPOPCORN = "CHICKENPOPCORN";
	public static final String CHICKENNUGGETS = "CHICKENNUGGETS";
	public static final String SILVERBOX = "SILVERBOX";
	
	
}
