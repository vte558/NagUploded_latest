package com.tkr.controller;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.tkr.cservice.TkrAdminOperationServiceImpl;

@RestController
public class TkrAdminOperationController {
	@Autowired
	TkrAdminOperationServiceImpl tkrAdminOperationServiceObj;

	@RequestMapping(value = "/retriveStockData", method = RequestMethod.GET)
	public String retriveStockData(ModelMap model) throws SQLException {

		Map<String, String> listMap = new HashMap<String, String>();
		ResultSet rs = tkrAdminOperationServiceObj.retriveStockData();

		while (rs.next()) {
			listMap.put("id", rs.getString("ProductName"));
			listMap.put("tags", rs.getString("quantity"));
		}

		System.out.println("listMap:::"+listMap.toString());
		model.addAttribute("retriveStockDataResult", listMap);
		return "/tkrStock";

	}

	@RequestMapping(value = "/updateStockData", method = RequestMethod.POST)
	public String updateStockData(@RequestParam("selectedprdid") String SelectedProd,
			@RequestParam("exisitngqtyid") String ExistingQnty, @RequestParam("qntyupdateid") String UpdateQnty)
			throws SQLException {

		tkrAdminOperationServiceObj.updateStockData(SelectedProd, ExistingQnty, UpdateQnty);

		return null;

	}

}
