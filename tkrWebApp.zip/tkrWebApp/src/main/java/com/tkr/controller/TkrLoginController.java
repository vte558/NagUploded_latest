package com.tkr.controller;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import com.tkr.cservice.TkrLoginServiceImpl;

@Controller
public class TkrLoginController {

	@Autowired(required = true)
	private TkrLoginServiceImpl serviceObj;

	@RequestMapping(value = "/tkr", method = RequestMethod.GET)
	public String indexPage(ModelMap model) {
		return "index";
	}

	@SuppressWarnings("null")
	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public String SystemloginValidate(@RequestParam("sysUserName") String sysUserName,
			@RequestParam("sysUserPwd") String sysUserPwd) throws SQLException {
		ResultSet rs = null;
		try {
			rs = serviceObj.loginValidate(sysUserName, sysUserPwd);
		} catch (Exception e) {
			e.printStackTrace();
		}

		if (rs.next())
			return "executiveOrAdminLogin";
		else
			return "index";
	}

	@RequestMapping(value = "/ExecutiveLogin", method = RequestMethod.POST)
	public String executiveLoginValidate(@RequestParam("executiveUserName") String userid,
			@RequestParam("executivePwd") String pwd) throws SQLException {
		ResultSet rs = null;
		try {
			rs = serviceObj.executiveLoginValidate(userid, pwd);
		} catch (Exception e) {
			e.printStackTrace();
		}

		if (rs.next())
			return "tkrSale";
		else
			return "index";
	}

	@RequestMapping(value = "/AdminLogin", method = RequestMethod.POST)
	public String adminLoginValidate(@RequestParam("adminUserName") String userid, @RequestParam("adminPwd") String pwd)
			throws SQLException {
		ResultSet rs = null;
		try {
			rs = serviceObj.adminLoginValidate(userid, pwd);
		} catch (Exception e) {
			e.printStackTrace();
		}

		if (rs.next())
			return "tkrStock";
		else
			return "index";
	}

}
