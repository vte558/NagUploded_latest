package com.tkr.vo;

public class LoginVO {

	private boolean loginresponse;

	public boolean isLoginresponse() {
		return loginresponse;
	}

	public void setLoginresponse(boolean loginresponse) {
		this.loginresponse = loginresponse;
	}

}