package com.tkr.cservice;

import java.sql.ResultSet;

import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.tkr.dao.TkrAdminDAOImpl;
@Component
public class TkrAdminOperationServiceImpl {
	@Autowired
	TkrAdminDAOImpl tkrAdminDAOImplObj;

	@RequestMapping(value = "", method = RequestMethod.POST)
	public ResultSet retriveStockData() throws SQLException {

		ResultSet rs = tkrAdminDAOImplObj.retriveStockData();
System.out.println("inTkrAdminController.jva"+rs);
		return rs;

	}

	@RequestMapping(value = "", method = RequestMethod.POST)
	public String updateStockData(String SelectedProd, String ExistingQnty, String UpdateQnty) throws SQLException {

		tkrAdminDAOImplObj.updateStockData(SelectedProd, ExistingQnty, UpdateQnty);

		return null;

	}
}
