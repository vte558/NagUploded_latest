package com.tkr.cservice;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.tkr.dao.TkrExecutiveSaleDAOImpl;
import com.tkr.product.catergories.ColdCoffees;
import com.tkr.product.catergories.Crushers;
import com.tkr.product.catergories.Icecreams;
import com.tkr.product.catergories.Lassis;
import com.tkr.product.catergories.Smoothies;
import com.tkr.product.catergories.Snacks;
import com.tkr.product.catergories.ThickShakes;

@Component
public class TkrExecutiveOperationServiceImpl {

	@Autowired (required = true)
	TkrExecutiveSaleDAOImpl tkrExecutiveSaleDAOImplObj;
	public String submitSaleItem(String selectedItem, String selectedSaleType,String selectedItemSize) throws SQLException {
		String ResultString = null;
		try {
		switch (selectedItem) {
		case "CrunchyMunch":
			ThickShakes ts = new ThickShakes();
			ts.crunchyMunchThickShake();
			break;
		case "FiveStar":
			ThickShakes ts1 = new ThickShakes();
			ts1.fiveStarThickShake();
			break;
		case "Snickers":
			ThickShakes ts2 = new ThickShakes();
			ts2.snickersThickShake();
			break;
		case "ChocopieKitkat":
			ThickShakes ts3 = new ThickShakes();
			ts3.chocoKitkatThickShake();
			break;
		case "Dairymilk":
			ThickShakes ts4 = new ThickShakes();
			ts4.dairyMilkThickShake();
			break;
		case "BelgiumDarkChoc":
			ThickShakes ts5 = new ThickShakes();
			ts5.belgiumDarkChocThickShake();
			break;
		case "Bourbon":
			ThickShakes ts6 = new ThickShakes();
			ts6.bourbonThickShake();
			break;
		case "HideNSeek":
			ThickShakes ts7 = new ThickShakes();
			ts7.hideNSeekThickShake();
			break;
		case "DarkFantasy":
			ThickShakes ts8 = new ThickShakes();
			ts8.darkFantasyThickShake();
			break;
		case "ChocoAlmond":
			ThickShakes ts9 = new ThickShakes();
			ts9.chocoAlmondThickShake();
			break;
		case "ChocoChips":
			ThickShakes ts10 = new ThickShakes();
			ts10.chocoChipsThickShake();
			break;
		case "RealOreo":
			ThickShakes ts11 = new ThickShakes();
			ts11.realOreoThickShake();
			break;
		case "OreoCaramel":
			ThickShakes ts12 = new ThickShakes();
			ts12.oreoCaramelThickShake();
			break;
		case "BananaOreo":
			ThickShakes ts13 = new ThickShakes();
			ts13.bananaOreoTickShake();
			break;
		case "OreoBrownie":
			ThickShakes ts14 = new ThickShakes();
			ts14.oreoBrownieTickShake();
			break;
		case "ClassicDoubleChocBrownie":
			ThickShakes ts15 = new ThickShakes();
			ts15.classicDoubleChocolateBrownieThickShake();
			break;
		case "TripleChocoBrownie":
			ThickShakes ts16 = new ThickShakes();
			ts16.tripleChocoBrownieThickShake();
			break;
		case "Nutella":
			ThickShakes ts17 = new ThickShakes();
			ts17.iconicNutellaThickShake();
			break;
		case "GulabJamun":
			ThickShakes ts18 = new ThickShakes();
			ts18.gulabJamunThickShake();
			break;
		case "SweetPan":
			ThickShakes ts19 = new ThickShakes();
			ts19.sweetPanThickShake();
			break;
		case "RosePetal":
			ThickShakes ts20 = new ThickShakes();
			ts20.rosePetalThickShake();
			break;

		case "NutsOverLoaded":
			ThickShakes ts21 = new ThickShakes();
			ts21.nutsOverLoadedThickShake();
			break;
		case "HealthyDates":
			ThickShakes ts22 = new ThickShakes();
			ts22.healthyDatesThickShake();
			break;

		case "DeleciousDryFruit":
			ThickShakes ts23 = new ThickShakes();
			ts23.deliciousDryFruitsThickShake();
			break;

		case "NutellaBrownie":
			ThickShakes ts24 = new ThickShakes();
			ts24.nutellaBrownieThickShake();
			break;

		case "BananaTS":
			Smoothies sm = new Smoothies();
			sm.bananaThickSmoothie();
			break;

		case "WaterMelonTS":
			Smoothies sm1 = new Smoothies();
			sm1.watermelonThickSmoothie();
			break;
		case "SapotaTS":
			Smoothies sm2 = new Smoothies();
			sm2.sapotaThickSmoothie();
			break;
		case "MuskmelonTS":
			Smoothies sm3 = new Smoothies();
			sm3.muskmelonThickSmoothie();
			break;
		case "AppleTS":
			Smoothies sm4 = new Smoothies();
			sm4.appleThickSmoothie();
			break;
		case "SeethapalTS":
			Smoothies sm5 = new Smoothies();
			sm5.seethapalThickSmoothie();
			break;

		case "ClassicColdCoffee":
			ColdCoffees cc = new ColdCoffees();
			cc.classicColdCoffee();
			break;

		case "OreoBlackCrunch":
			ColdCoffees cc1 = new ColdCoffees();
			cc1.oreoBlackCoffee();
			break;
		case "ChocoColdCoffee":
			ColdCoffees cc2 = new ColdCoffees();
			cc2.chocoColdCoffee();
			break;
		case "VirginMojito":
			Crushers cr = new Crushers();
			cr.virginMojito();
			break;
		case "PinaColada":
			Crushers cr1 = new Crushers();
			cr1.pinaColada();
			break;
		case "RjyRoseMilk":
			Crushers cr2 = new Crushers();
			cr2.rjyRoseMilk();
			break;

		case "CLASSICLASSI":
			Lassis ls = new Lassis();
			ls.classicLassi();
			break;
		case "BANANALASSI":
			Lassis ls1 = new Lassis();
			ls1.bananaLassi();
			break;
		case "GUAVALASSI":
			Lassis ls2 = new Lassis();
			ls2.guavaLassi();
			break;
		case "MANGOLASSI":
			Lassis ls3 = new Lassis();
			ls3.mangoLassi();
			break;
		case "GREENAPPLELASSI":
			Lassis ls4 = new Lassis();
			ls4.greenAppleLassi();
			break;
		case "MULBERRYLASSI":
			Lassis ls5 = new Lassis();
			ls5.mulberryLassi();
			break;
		case "PINEAPPLELASSI":
			Lassis ls6 = new Lassis();
			ls6.pineAppleLassi();
			break;
		case "ORANGELASSI":
			Lassis ls7 = new Lassis();
			ls7.orangeLassi();
			break;
		case "SPECIALLASSI":
			Lassis ls8 = new Lassis();
			ls8.specialLassi();
			break;
		case "LITCHILASSI":
			Lassis ls9 = new Lassis();
			ls9.litchiLassi();
			break;

		case "FRENCHFRIES":
			Snacks sn = new Snacks();
			sn.frenchFries();
			break;
		case "CHICKENPOPCORN":
			Snacks sn1 = new Snacks();
			sn1.chickenPopCorn();
			break;
		case "CHICKENNUGGETS":
			Snacks sn2 = new Snacks();
			sn2.chickenNuggets();
			break;
		case "CHICKENPLATTER":
			Snacks sn3 = new Snacks();
			sn3.chickenPlatter();
			break;
		case "FRENCHCOMBO":
			Snacks sn4 = new Snacks();
			sn4.frenchCombo();
			break;
		case "NUGGETSCOMBO":
			Snacks sn5 = new Snacks();
			sn5.nuggetsCombo();
			break;
		case "POPCORNCOMBO":
			Snacks sn6 = new Snacks();
			sn6.popcornCombo();
			break;

		case "VANILLA":
			Icecreams ic = new Icecreams();
			if (selectedItemSize.toString().trim().equals("Regular")) {
				String saleType = selectedSaleType;
				ic.vanillaICECREAMR(saleType);
			} else if (selectedItemSize.toString().trim().equalsIgnoreCase("Large")) {
				ic.vanillaICECREAML();
			}
			break;

		case "CHOCOLATEICECREAM":
			Icecreams ic1 = new Icecreams();
			if (selectedItemSize.toString().trim().equals("Regular")) {
				String saleType = selectedSaleType;
				ic1.chocolateICECREAMR(saleType);
			} else if (selectedItemSize.toString().trim().equalsIgnoreCase("Large")) {
				ic1.chocolateICECREAML();
			}

			break;
		case "BUTTERSCOTCHICECREAM":
			Icecreams ic2 = new Icecreams();
			if (selectedItemSize.toString().trim().equals("Regular")) {
				String saleType = selectedSaleType;
				ic2.butterScotchICECREAMR(saleType);
			} else if (selectedItemSize.toString().trim().equalsIgnoreCase("Large")) {
				ic2.butterScotchICECREAML();
			}
			break;

		case "JAMICANICECREAM":

			Icecreams ic3 = new Icecreams();
			if (selectedItemSize.toString().trim().equalsIgnoreCase("Regular")) {
				String saleType = selectedSaleType;
				ic3.jamicanICECREAMR(saleType);
			} else if (selectedItemSize.toString().trim().equalsIgnoreCase("Large")) {
				ic3.jamicanICECREAML();
			}

			break;
		case "BELGIUMDARKCHOCICECREAM":
			Icecreams ic4 = new Icecreams();
			if (selectedItemSize.toString().trim().equals("Regular")) {
				String saleType = selectedSaleType;
				ic4.belgiumDarkChocICECREAMR(saleType);
			} else if (selectedItemSize.toString().trim().equalsIgnoreCase("Large")) {
				ic4.belgiumDarkChocICECREAML();
			}

			break;
		case "JAGGERYICECREAM":
			Icecreams ic5 = new Icecreams();
			if (selectedItemSize.toString().trim().equals("Regular")) {
				String saleType = selectedSaleType;
				ic5.jaggeryICECREAMR(saleType);
			} else if (selectedItemSize.toString().trim().equalsIgnoreCase("Large")) {
				ic5.jaggeryICECREAML();
			}
			break;

		case "NUTTYCARAMELICECREAM":
			Icecreams ic6 = new Icecreams();
			if (selectedItemSize.toString().trim().equals("Regular")) {
				String saleType = selectedSaleType;
				ic6.NuttyCaramelICECREAMR(saleType);
			} else if (selectedItemSize.toString().trim().equalsIgnoreCase("Large")) {
				ic6.NuttyCaramelICECREAML();
			}
			break;

		case "FRUITJELLYICECREAM":
			Icecreams ic7 = new Icecreams();
			if (selectedItemSize.toString().trim().equals("Regular")) {
				String saleType = selectedSaleType;
				ic7.fruitJellyICECREAMR(saleType);
			} else if (selectedItemSize.toString().trim().equalsIgnoreCase("Large")) {
				ic7.fruitJellyICECREAML();
			}
			break;

		case "HONEYALMONDICECREAM":
			Icecreams ic8 = new Icecreams();
			if (selectedItemSize.toString().trim().equals("Regular")) {
				String saleType = selectedSaleType;
				ic8.honeyAlmondICECREAMR(saleType);
			} else if (selectedItemSize.toString().trim().equalsIgnoreCase("Large")) {
				ic8.honeyAlmondICECREAML();
			}

			break;
		case "SHAHIGULABICECREAM":
			Icecreams ic9 = new Icecreams();
			if (selectedItemSize.toString().trim().equals("Regular")) {
				String saleType = selectedSaleType;
				ic9.shahiGulabICECREAMR(saleType);
			} else if (selectedItemSize.toString().trim().equalsIgnoreCase("Large")) {
				ic9.shahiGulabICECREAML();
			}
			break;

		case "PANMASALAICECREAM":
			Icecreams ic10 = new Icecreams();
			if (selectedItemSize.toString().trim().equals("Regular")) {
				String saleType = selectedSaleType;
				ic10.panMasalaICECREAMR(saleType);
			} else if (selectedItemSize.toString().trim().equalsIgnoreCase("Large")) {
				ic10.panMasalaICECREAML();
			}
			break;

		case "BIRTHDAYCAKEICECREAM":
			Icecreams ic11 = new Icecreams();
			if (selectedItemSize.toString().trim().equals("Regular")) {
				String saleType = selectedSaleType;
				ic11.birthdaycakeICECREAMR(saleType);
			} else if (selectedItemSize.toString().trim().equalsIgnoreCase("Large")) {
				ic11.birthdaycakeICECREAML();
			}

			break;
		case "ANJEERBADAMICECREAM":
			Icecreams ic12 = new Icecreams();
			if (selectedItemSize.toString().trim().equals("Regular")) {
				String saleType = selectedSaleType;
				ic12.anjeerBadamICECREAMR(saleType);
			} else if (selectedItemSize.toString().trim().equalsIgnoreCase("Large")) {
				ic12.anjeerBadamICECREAML();
			}
			break;

		case "DRYFRUITSICECREAM":
			Icecreams ic13 = new Icecreams();
			if (selectedItemSize.toString().trim().equals("Regular")) {
				String saleType = selectedSaleType;
				ic13.dryFruitsICECREAMR(saleType);
			} else if (selectedItemSize.toString().trim().equalsIgnoreCase("Large")) {
				ic13.dryFruitsICECREAML();
			}
			break;

		case "DOUBLECHOCBROWNIEIC":
			Icecreams ic14 = new Icecreams();
			ic14.doubleChocBrownieWithIcecream();
			break;
		}

		
		 ResultString =tkrExecutiveSaleDAOImplObj.submitSaleItem(selectedItem, selectedSaleType, selectedItemSize);
	} catch (Exception e) {
		e.printStackTrace();
	}
		return ResultString;
	}
}
