package com.tkr.cservice;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.tkr.dao.TkrLoginDAOImpl;
import com.tkr.vo.LoginVO;

@Component
public class TkrLoginServiceImpl {
	@Autowired(required = true)
	TkrLoginDAOImpl daoImplObj;
	LoginVO loginVO;

	public ResultSet loginValidate(String Userid, String pwd) throws SQLException {
		ResultSet rs = null;
		try {
			rs = daoImplObj.LoginValidate(Userid, pwd);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return rs;

	}

	public ResultSet executiveLoginValidate(String Userid, String pwd) throws SQLException {
		ResultSet rs = null;
		try {
			rs = daoImplObj.executiveLoginValidate(Userid, pwd);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return rs;

	}

	public ResultSet adminLoginValidate(String Userid, String pwd) throws SQLException {
		ResultSet rs = null;
		try {
			rs = daoImplObj.adminLoginValidate(Userid, pwd);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return rs;

	}
}
