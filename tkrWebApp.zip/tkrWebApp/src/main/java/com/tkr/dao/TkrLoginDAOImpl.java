package com.tkr.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.tkr.util.GetConnection;

@Component
public class TkrLoginDAOImpl {

	@Autowired(required = true)
	private GetConnection getConnectionObj;

	public ResultSet LoginValidate(String userid, String pwd) throws SQLException {
		Connection con = getConnectionObj.getConnection();
		Statement st = null;
		ResultSet rs = null;
		try {
			st = con.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Error at Obaining connection from AWS rds :" + e);
			e.printStackTrace();
		}
		try {
			rs = st.executeQuery("select * from tkrusers where email='" + userid + "' and pass='" + pwd + "'");
		} catch (SQLException e) {
			System.out.println("Error In LoginValidate() :" + e);
		}

		return rs;
	}

	public ResultSet executiveLoginValidate(String userid, String pwd) throws SQLException {
		Connection con = getConnectionObj.getConnection();
		Statement st = null;
		ResultSet rs = null;
		try {
			st = con.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Error at Obaining connection from AWS rds :" + e);
			e.printStackTrace();
		}
		try {
			rs = st.executeQuery("select * from tkrusers where email='" + userid + "' and pass='" + pwd + "'");
		} catch (SQLException e) {
			System.out.println("Error In LoginValidate() :" + e);
		}

		return rs;
	}

	public ResultSet adminLoginValidate(String userid, String pwd) throws SQLException {
		Connection con = getConnectionObj.getConnection();
		Statement st = null;
		ResultSet rs = null;
		try {
			st = con.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Error at Obaining connection from AWS rds :" + e);
			e.printStackTrace();
		}
		try {
			rs = st.executeQuery("select * from tkrusers where email='" + userid + "' and pass='" + pwd + "'");
		} catch (SQLException e) {
			System.out.println("Error In LoginValidate() :" + e);
		}

		return rs;
	}
}
