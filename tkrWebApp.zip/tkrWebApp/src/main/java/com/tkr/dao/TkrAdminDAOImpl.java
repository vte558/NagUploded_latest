package com.tkr.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.tkr.util.GetConnection;

@Controller
public class TkrAdminDAOImpl {
	@Autowired
	GetConnection getConnectionObj;

	public ResultSet retriveStockData() throws SQLException {

		Connection con = getConnectionObj.getConnection();
		Statement st = null;

		try {
			st = con.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Error at Obaining connection from AWS rds :" + e);
			e.printStackTrace();
		}
		ResultSet reslultset = st.executeQuery("select * from tkr_products order by ProductName asc");

		return reslultset;

	}

	public String updateStockData(String SelectedProd, String ExistingQnty, String UpdateQnty) throws SQLException {

		Connection con = getConnectionObj.getConnection();
		Statement st = null;

		int quantity1 = Integer.parseInt(UpdateQnty);
		int quantity2 = Integer.parseInt(ExistingQnty);
		int quantity = quantity1 + quantity2;

		try {
			st = con.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Error at Obaining connection from AWS rds :" + e);
			e.printStackTrace();
		}
		st.executeUpdate(
				"update tkr_products set quantity='" + quantity + "' where ProductName='" + SelectedProd + "'");

		return null;

	}
}
