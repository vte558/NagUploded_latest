package com.tkr.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.tkr.util.GetConnection;

@Component
public class TkrExecutiveSaleDAOImpl {
	@Autowired(required = true)
	private GetConnection getConnectionObj;

	public String submitSaleItem(String selectedItem, String selectedSaleType, String selectedItemSize)
			throws SQLException {

		Connection con = getConnectionObj.getConnection();
		String str1 = "";
		System.out.println();
		if (selectedItem.toString().trim().contains("ICECREAM")) {
			System.out.println("inside If..the item selected is Some ICECREAM--->" + selectedItem.toString().trim());
			str1 = "select Price from tkr_items_price where ProductName='" + selectedItem.toString().trim()
					+ "'and Saletype='" + selectedSaleType.toString().trim() + "'and Itemsize='"
					+ selectedItemSize.toString().trim() + "';";

		} else if (selectedItem.toString().trim().contains("VANILLA")) {

			str1 = "select Price from tkr_items_price where ProductName='" + selectedItem.toString().trim()
					+ "'and Saletype='" + selectedSaleType.toString().trim() + "'and Itemsize='"
					+ selectedItemSize.toString().trim() + "';";
			System.out.println("inside 1st elseif..the item selected is VANILLA--->" + selectedItem.toString().trim());
		} else {
			String Itemsize = "Regular";

			System.out.println("inside 2nd elseif..the item selected is not IC--->" + selectedItem.toString().trim());
			str1 = "select Price from tkr_items_price where ProductName='" + selectedItem.toString().trim()
					+ "'and Saletype='" + selectedSaleType.toString().trim() + "'";

		}
		System.out.println("str1111 in TkrExecutiveSaleDAOImpl" + str1);

		String itemsizee = "Regular";
		if (selectedItemSize != null) {

			itemsizee = selectedItemSize.toString().trim();
		}
		System.out.println("item sizee" + itemsizee);

		PreparedStatement stmt1 = con.prepareStatement(str1);
		ResultSet rs1 = stmt1.executeQuery();
		while (rs1.next()) {
			String Price = rs1.getString("Price");

			System.out.println("in SaleProcess page " + Price);

			String str2 = "insert into tkr_sales ( Date,ProductName,Itemsize,Saletype,Price) values(convert(varchar, getdate(), 23),?,?,?,?)";
			System.out.println("str2--->" + str2);
			PreparedStatement stmt = con.prepareStatement(str2);
			stmt.setString(1, selectedItem.trim());
			stmt.setString(2, itemsizee);
			stmt.setString(3, selectedSaleType.trim());
			stmt.setString(4, Price);
			stmt.executeUpdate();
			stmt.close();
		}
		return itemsizee;
	}
}
